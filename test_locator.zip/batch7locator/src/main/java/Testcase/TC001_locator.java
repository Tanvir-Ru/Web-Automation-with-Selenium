package Testcase;


import java.time.Duration;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import Base.DriverSetup;

public class TC001_locator extends DriverSetup {
	String baseUrl=" https://rahulshettyacademy.com/locatorspractice/";
	
	
	@Test
	public void locatorlearning() throws InterruptedException
	{
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		
		
		driver.findElement(By.id("inputUsername")).sendKeys("Tanvir");;

		driver.findElement(By.name("inputPassword")).sendKeys("passwordField");
		
		driver.findElement(By.className("signInBtn")).click();
		

		
		System.out.println(driver.findElement(By.cssSelector("p.error")).getText());;
		
	
		driver.findElement(By.linkText("Forgot your password?")).click();
		
		
		
		driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys("Hossain");

		
	    driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys("tanvir@gmail.com");
	 
	    driver.findElement(By.xpath("//input[@type='text'][3]")).sendKeys("01758779822");
	    
	    Thread.sleep(2000);
		
		
		
	    driver.findElement(By.cssSelector("reset-pwd-btn")).click();
	    
	    
	    driver.findElement(By.xpath("//div[@class='forgot-pwd-btn-conainer']/button[1]")).click();
	    
	    
	    
	    driver.findElement(By.cssSelector("#inputUserName")).sendKeys("Badhon");
	    driver.findElement(By.cssSelector("input[type*='pass']")).sendKeys("rahulshettyacademy");
	    
	    
	    driver.findElement(By.id("chkboxOne")).click();
	    
	    driver.findElement(By.xpath("//button[contains(@class,'submit')]")).click();
	   
	} 
	

}
